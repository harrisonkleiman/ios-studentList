//
//  StudentController.swift
//  Student List
//
//  Created by Harrison Kleiman on 4/28/22.
//

import Foundation

class StudentController {
    
    static var students: [Student] {
        return [
            Student(firstName: "Harrison", lastName: "Kleiman", age: 23),
            Student(firstName: "Steve", lastName: "Wozniak", age: 71),
            Student(firstName: "Johnny", lastName: "Appleseed", age: 200)
        ]
    }
}
