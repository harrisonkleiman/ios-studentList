//
//  StudentDetailViewController.swift
//  Student List
//
//  Created by Harrison Kleiman on 4/28/22.
//

import UIKit

class StudentDetailViewController: UIViewController {
    
     override func viewDidLoad() {
        super.viewDidLoad()
        
        updateViews()
    }
    
    private func updateViews() {
        guard let student = student, isViewLoaded else {return}
        
        firstNameLabel.text = student.firstName
        lastNameLabel.text = student.lastName
        // Age is an Int. Change to String
        ageLabel.text = "\(student.age)" // changes to String
    }
    var student: Student? {
        didSet {
            updateViews()
        }
    }

    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
}
